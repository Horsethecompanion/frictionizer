# Frictionizer — Icon Assets v2

Drop each folder/file into the corresponding location in your Android Studio project
under `app/src/main/res/`. Android Studio will pick them up on the next sync.

## Directory map

```
mipmap-mdpi/
  ic_launcher.png           →  res/mipmap-mdpi/ic_launcher.png
  ic_launcher_round.png     →  res/mipmap-mdpi/ic_launcher_round.png
  ic_launcher_foreground.png→  res/mipmap-mdpi/ic_launcher_foreground.png

mipmap-hdpi/                →  res/mipmap-hdpi/   (same three files)
mipmap-xhdpi/               →  res/mipmap-xhdpi/
mipmap-xxhdpi/              →  res/mipmap-xxhdpi/
mipmap-xxxhdpi/             →  res/mipmap-xxxhdpi/

mipmap-anydpi-v26/
  ic_launcher.xml           →  res/mipmap-anydpi-v26/ic_launcher.xml
  ic_launcher_round.xml     →  res/mipmap-anydpi-v26/ic_launcher_round.xml

drawable/
  logo_frictionizer.png     →  res/drawable/logo_frictionizer.png
                                (replaces the old placeholder — shown in white
                                 card on the main screen)
  frictionizer_wordmark.png →  res/drawable/frictionizer_wordmark.png
                                (toolbar/header use, 24dp tall)
  frictionizer_wordmark_large.png
                            →  res/drawable/frictionizer_wordmark_large.png
                                (main screen header, 40dp tall)
```

## colors.xml

Add one line to `res/values/colors.xml` inside the `<resources>` block:

    <color name="ic_launcher_background">#FFFFFF</color>

This sets the adaptive icon background to white (matching the logo's own bg).

## What each icon type is for

| File | Used by |
|---|---|
| `ic_launcher.png` (mipmap-*) | App drawer on older devices / Android <8 |
| `ic_launcher_round.png` (mipmap-*) | Round icon variant (Pixel, some Samsung) |
| `ic_launcher_foreground.png` (mipmap-*) | Adaptive icon foreground (API 26+) |
| `mipmap-anydpi-v26/*.xml` | Tells Android 8+ to use the adaptive icon |

## Sizes reference

| Folder | px | dp equivalent |
|---|---|---|
| mipmap-mdpi | 48 × 48 | 48dp |
| mipmap-hdpi | 72 × 72 | 48dp |
| mipmap-xhdpi | 96 × 96 | 48dp |
| mipmap-xxhdpi | 144 × 144 | 48dp |
| mipmap-xxxhdpi | 192 × 192 | 48dp |
| adaptive foreground (mdpi) | 108 × 108 | 108dp |
| adaptive foreground (xxxhdpi) | 432 × 432 | 108dp |
